/**
 * Internal dependencies
 */
import './product/title';
import './product/price';
import './product/image';
import './product/rating';
import './product/button';
import './product/summary';
import './product/sale-badge';
import './product/sku';
