/**
 * Internal dependencies
 */
import Block from './block';

export default ( { attributes } ) => {
	return <Block { ...attributes } />;
};
