export const blockAttributes = {
	headingLevel: {
		type: 'number',
		default: 2,
	},
	productLink: {
		type: 'boolean',
		default: true,
	},
};

export default blockAttributes;
