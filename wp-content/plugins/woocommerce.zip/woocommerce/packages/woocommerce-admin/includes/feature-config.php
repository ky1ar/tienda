<?php
// WARNING: Do not directly edit this file.
// This file is auto-generated as part of the build process and things may break.
if ( ! function_exists( 'wc_admin_get_feature_config' ) ) {
	function wc_admin_get_feature_config() {
		return array(
			'activity-panels' => true,
			'analytics' => true,
			'analytics-dashboard' => true,
			'analytics-dashboard/customizable' => true,
			'coupons' => false,
			'devdocs' => false,
			'marketing' => true,
			'navigation' => false,
			'onboarding' => true,
			'remote-inbox-notifications' => false,
			'shipping-label-banner' => true,
			'store-alerts' => true,
			'unminified-js' => false,
			'wcpay' => true,
			'homescreen' => true,
		);
	}
}
